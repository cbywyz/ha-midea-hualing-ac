from homeassistant.const import Platform, UnitOfTemperature, UnitOfTime, PERCENTAGE, PRECISION_WHOLE
from homeassistant.components.sensor import SensorStateClass, SensorDeviceClass
from homeassistant.components.binary_sensor import BinarySensorDeviceClass
from homeassistant.components.switch import SwitchDeviceClass

DEVICE_MAPPING = {
    "default": {
        "manufacturer": "美的",
        "rationale": ["off", "on"],
        "queries": [{}],
        "centralized": [],
        "entities": {
            Platform.NUMBER: {
                "water_quality": {
                    "min": 0,
                    "max": 3,
                    "step": 1
                }
            },
            Platform.CLIMATE: {
                "water_heater": {
                    "power": "power",
                    "hvac_modes": {
                        "off": {"power": "off"},
                        "heat": {"power": "on"},
                    },
                    "target_temperature": "temperature",
                    "current_temperature": "cur_temperature",
                    "min_temp": 30,
                    "max_temp": 80,
                    "temperature_unit": UnitOfTemperature.CELSIUS,
                    "precision": PRECISION_WHOLE,
                }
            },
            Platform.SWITCH: {
                "power": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "ti_protect": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "auto_off": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "protect": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "sleep": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "memory": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "safe": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "water_flow": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "sterilization": {
                    "device_class": SwitchDeviceClass.SWITCH,
                }
            },
            Platform.SENSOR: {
                "temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "cur_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "top_temp": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "bottom_temp": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "in_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "passwater_lowbyte": {
                    "device_class": SensorDeviceClass.WATER,
                    "unit_of_measurement": "L",
                    "state_class": SensorStateClass.TOTAL
                },
                "passwater_highbyte": {
                    "device_class": SensorDeviceClass.WATER,
                    "unit_of_measurement": "L",
                    "state_class": SensorStateClass.TOTAL
                },
                "rate": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "cur_rate": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "sterilize_left_days": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.DAYS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "uv_sterilize_minute": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "uv_sterilize_second": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.SECONDS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "screen_light": {
                    "device_class": SensorDeviceClass.ILLUMINANCE,
                    "unit_of_measurement": "lx",
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "morning_night_bash": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "tds_value": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "heat_water_level": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "flow": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "end_time_hour": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.HOURS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "end_time_minute": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "wash_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "sterilize_cycle_index": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "discharge_status": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "error_code": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "water_system": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "discharge_left_time": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "mg_remain": {
                    "device_class": SensorDeviceClass.ENUM
                },
                "waterday_lowbyte": {
                    "device_class": SensorDeviceClass.WATER,
                    "unit_of_measurement": "L",
                    "state_class": SensorStateClass.TOTAL
                },
                "waterday_highbyte": {
                    "device_class": SensorDeviceClass.WATER,
                    "unit_of_measurement": "L",
                    "state_class": SensorStateClass.TOTAL
                }
            },
            Platform.BINARY_SENSOR: {
                "door_status": {
                    "device_class": BinarySensorDeviceClass.DOOR,
                },
                "limit_error": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                },
                "sensor_error": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                },
                "communication_error": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                },
                "ele_exception": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                },
                "elec_warning": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                }
            }
        }
    },
    "510214FN": {
        "manufacturer": "美的",
        "rationale": ["off", "on"],
        "queries": [{}],
        "centralized": [],
        "calculate": {
            "get": [
                {
                    "lvalue": "[end_time]",
                    "rvalue": "[end_time_hour] * 60 + [end_time_minute]"
                }
            ],
            "set": {
            }
        },
        "entities": {
            Platform.CLIMATE: {
                "water_heater": {
                    "power": "power",
                    "hvac_modes": {
                        "off": {"power": "off"},
                        "heat": {"power": "on"},
                    },
                    "target_temperature": "temperature",
                    "current_temperature": "cur_temperature",
                    "min_temp": 30,
                    "max_temp": 75,
                    "temperature_unit": UnitOfTemperature.CELSIUS,
                    "precision": PRECISION_WHOLE
                }
            },
            Platform.SELECT: {
                "heat": {
                    "options": {
                        "half": {"half_heat": "on", "whole_heat": "off"},
                        "whole": {"half_heat": "off", "whole_heat": "on"}
                    },
                    "translation_key": "heating_capacity"
                }
            },
            Platform.SWITCH: {
                "power": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "eplus": {
                    "device_class": SwitchDeviceClass.SWITCH,
                    "translation_key": "e_capacity"
                },
                "efficient": {
                    "device_class": SwitchDeviceClass.SWITCH,
                    "translation_key": "low_energy_save"
                },
                "night": {
                    "device_class": SwitchDeviceClass.SWITCH,
                    "translation_key": "night_electricity_cloud"
                },
                "sterilization": {
                    "device_class": SwitchDeviceClass.SWITCH,
                    "translation_key": "sterilize_high_temp"
                }
            },
            Platform.SENSOR: {
                "cur_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "current_water_temperature"
                },
                "temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "target_water_temperature"
                },
                "heat_water_level": {
                    "unit_of_measurement": PERCENTAGE,
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "hot_water_amount"
                },
                "end_time": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "heating_remaining_time"
                },
                "water_quality": {
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "water_quality_score"
                },
                "in_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "error_code": {
                    "device_class": SensorDeviceClass.ENUM,
                    "translation_key": "fault_code"
                }
            },
            Platform.BINARY_SENSOR: {
                "communication_error": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                    "translation_key": "communication_exception"
                },
                "sensor_error": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                    "translation_key": "sensor_exception"
                },
                "limit_error": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                    "translation_key": "limit_exception"
                },
                "ele_exception": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                    "translation_key": "mains_power_exception"
                },
                "elec_warning": {
                    "device_class": BinarySensorDeviceClass.PROBLEM,
                    "translation_key": "electrical_warning"
                }
            }
        }
    },
    ("510214HB", "5102152H"): {
        "rationale": ["off", "on"],
        "queries": [{}],
        "centralized": [],
        "calculate": {
            "get": [
                {
                    "lvalue": "[end_time]",
                    "rvalue": "[end_time_hour] * 60 + [end_time_minute]"
                }
            ],
            "set": {
            }
        },
        "entities": {
            Platform.CLIMATE: {
                "water_heater": {
                    "power": "power",
                    "hvac_modes": {
                        "off": {"power": "off"},
                        "heat": {"power": "on"},
                    },
                    "target_temperature": "temperature",
                    "current_temperature": "cur_temperature",
                    "min_temp": 30,
                    "max_temp": 75,
                    "temperature_unit": UnitOfTemperature.CELSIUS,
                    "precision": PRECISION_WHOLE
                }
            },
            Platform.SWITCH: {
                "power": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "protect": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "smart_sterilize": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "eplus": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "frequency_hot": {
                    "device_class": SwitchDeviceClass.SWITCH,
                }
            },
            Platform.SENSOR: {
                "temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "temp_set"
                },
                "cur_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "end_time": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "error_code": {
                    "device_class": SensorDeviceClass.ENUM
                }
            }
        }
    },
    "51001938": {
        "rationale": ["off", "on"],
        "queries": [{}],
        "centralized": [],
        "calculate": {
            "get": [
                {
                    "lvalue": "[end_time]",
                    "rvalue": "[end_time_hour] * 60 + [end_time_minute]"
                }
            ],
            "set": {
            }
        },
        "entities": {
            Platform.CLIMATE: {
                "water_heater": {
                    "power": "power",
                    "hvac_modes": {
                        "off": {"power": "off"},
                        "heat": {"power": "on"},
                    },
                    "target_temperature": "temperature",
                    "current_temperature": "cur_temperature",
                    "min_temp": 30,
                    "max_temp": 75,
                    "temperature_unit": UnitOfTemperature.CELSIUS,
                    "precision": PRECISION_WHOLE
                }
            },
            Platform.SWITCH: {
                "power": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "efficient": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "auto_off": {
                    "device_class": SwitchDeviceClass.SWITCH,
                },
                "frequency_hot": {
                    "device_class": SwitchDeviceClass.SWITCH,
                }
            },
            Platform.SENSOR: {
                "temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT,
                    "translation_key": "temp_set"
                },
                "cur_temperature": {
                    "device_class": SensorDeviceClass.TEMPERATURE,
                    "unit_of_measurement": UnitOfTemperature.CELSIUS,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "end_time": {
                    "device_class": SensorDeviceClass.DURATION,
                    "unit_of_measurement": UnitOfTime.MINUTES,
                    "state_class": SensorStateClass.MEASUREMENT
                },
                "error_code": {
                    "device_class": SensorDeviceClass.ENUM
                }
            }
        }
    }
}
